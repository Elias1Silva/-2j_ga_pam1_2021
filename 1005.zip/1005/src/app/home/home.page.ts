import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  numero = '';

  constructor() {}

 limpar(){
   this.numero = '';
 }
 sete(){
   this.numero = this.numero + '7';
 }
 oito(){
   this.numero = this.numero + '8';
 }
 nove(){
   this.numero = this.numero + '9';
 }
 dividir(){

 }
 quatro(){
   this.numero = this.numero + '4';
 }
 cinco(){
   this.numero = this.numero + '5';
 }
 seis(){
   this.numero = this.numero + '6';
 }
 multiplicar(){

 }
 um(){
   this.numero = this.numero + '1';
 }
 dois(){
   this.numero = this.numero + '2';
 }
 tres(){
   this.numero = this.numero + '3';
 }
 subtrair(){

 }
 ponto(){

 }
 zero(){
   this.numero = this.numero + '0';
 }

 igualar(){

 }
 somar(){
  const somar = this.numero + this.numero;
 }
}
