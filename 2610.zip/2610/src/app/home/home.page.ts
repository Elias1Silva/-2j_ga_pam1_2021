import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  display = '';
  memoria = '';
  operacao = "";
  auxiliar = "";
  usouPonto = false;
  estaVazio = true;

  constructor() {}


  clicar(numero: string){
    this.display = this.display + numero;

    this.verificarDisplayVazio();
  }
  verificarDisplayVazio(){
    if(this.display.length !== 0){
      this.estaVazio = false;
    }
  }


  usarPonto(){
    if(this.display === ''){
      this.display = this.display + "0";
    }
    this.display = this.display + ".";
    this.usouPonto = true;
  }


 calcular(operacao: string){
   this.usouPonto = false;
   this.estaVazio = true;

   if(this.memoria === '' && this.auxiliar === ''){
    this.memoria = this.display;
    this.display = '';
    this.operacao = operacao;
    this.estaVazio = true;
  }else if (operacao === "="){
    if(this.memoria !== ""){
      this.auxiliar = this.display;
    }
    switch(this.operacao){
      case '+': this.somar(); break;
      case '-': this.subtrair(); break;
      case '*': this.multiplicar(); break;
      case '/': this.dividir(); break;
    }
    this.estaVazio = false;
    this.memoria = "";

  }else{
    console.log("Já tem um valor na memória: " + this.memoria);
  }
 }
 somar(){
    let n1 = 0;
    let n2 = 0;
    let resp = 0

    if(this.memoria !== ""){
    n1 = parseFloat(this.memoria);
    n2 = parseFloat(this.display);
   }
   resp = n1 + n2;

   this.display = resp.toString();

   this.memoria = '';
 }
 subtrair(){
   const n1 = parseFloat(this.memoria);
   const n2 = parseFloat(this.display);
   const resp = n1 - n2;

   this.display = resp.toString();

   this.memoria = '';
 }
 multiplicar(){
  const n1 = parseFloat(this.memoria);
  const n2 = parseFloat(this.display);
  const resp = n1 * n2;

  this.display = resp.toString();

  this.memoria = '';
 }
 dividir(){
  const n1 = parseFloat(this.memoria);
  const n2 = parseFloat(this.display);
  const resp = n1 / n2;

  this.display = resp.toString();

  this.memoria = '';
 }
 limpar(){
   this.display = '';
   this.memoria = '';
   this.operacao = '';
   this.usouPonto = false;
   this.estaVazio = true;
 }

}
