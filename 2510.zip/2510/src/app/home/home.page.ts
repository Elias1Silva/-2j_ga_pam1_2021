import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  display = '';
  memoria = '';
  operacao = "";

  constructor() {}


  clicar(numero: string){
    this.display = this.display + numero;
  }
 calcular(operacao: string){
   if(this.memoria === ''){
    this.memoria = this.display;
    this.display = '';
    this.operacao = operacao;
  }else if (operacao === "="){
    switch(this.operacao){
      case '+': this.somar(); break;
      case '-': this.subtrair(); break;
      case '*': this.multiplicar(); break;
      case '/': this.dividir(); break;
    }

  }else{
    console.log("Já tem um valor na memória: " + this.memoria);
  }
 }
 somar(){
   const n1 = parseFloat(this.memoria);
   const n2 = parseFloat(this.display);
   const resp = n1 + n2;

   this.display = resp.toString();

   this.memoria = '';
 }
 subtrair(){
   const n1 = parseFloat(this.memoria);
   const n2 = parseFloat(this.display);
   const resp = n1 - n2;

   this.display = resp.toString();

   this.memoria = '';
 }
 multiplicar(){
  const n1 = parseFloat(this.memoria);
  const n2 = parseFloat(this.display);
  const resp = n1 * n2;

  this.display = resp.toString();

  this.memoria = '';
 }
 dividir(){
  const n1 = parseFloat(this.memoria);
  const n2 = parseFloat(this.display);
  const resp = n1 / n2;

  this.display = resp.toString();

  this.memoria = '';
 }
 limpar(){
   this.display = '';

 }

}
